import logo from './logo.svg';
import './App.css';
import AppHeader from './components/Header';
import AppGud from './components/Gud';
import AppData from './components/Data';

function App() {
  return (
    <div className="App">
      <AppHeader />
      <AppGud />
      <AppData />
    </div>
  );
}

export default App;
