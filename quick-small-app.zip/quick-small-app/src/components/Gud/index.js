import "./index.css";
// import Img from '../../assets/img/GUD-btn.webp';

const AppGud = () => {
  return (
    <div className="app-gud">
      {/* <img src={Img} /> */}
      <div className="app-gud-img">IMG</div>
      <div className="app-gud-help"> Help Joe Harvest Gud Rewards </div>
      <div className="app-gud-smash ">
        Smash the GUD button and it will burn tax and harvest GUD rewards!{" "}
      </div>
    </div>
  );
};

export default AppGud;
