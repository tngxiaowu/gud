import "./index.css";

const AppData = () => {
  return (
    <div className="app-data">
      <div className="app-data-harvested">
        <div className="app-data-harvested-list">
          <div className="app-data-harvested-list-item">
            <div className="app-data-harvested-list-item_number">20652</div>
            <div className="app-data-harvested-list-item_text">
              Gud Rewards Harvested
            </div>
          </div>
          <div className="app-data-harvested-list-item">
            <div className="app-data-harvested-list-item_number">3467</div>
            <div className="app-data-harvested-list-item_text">
              Friends of Joe
            </div>
          </div>
          <div className="app-data-harvested-list-item">
            <div className="app-data-harvested-list-item_number"> ...</div>
            <div className="app-data-harvested-list-item_text">
              Getting Harvested for you
            </div>
          </div>
        </div>
      </div>
      <div className="app-data-buy">
        <div className="app-data-buy-btn">BUY RPG</div>
        <div className="app-data-buy-tax">Buy 6% / Sell 6% Tax</div>
        <div className="app-data-buy-rewards">(5% Rewards, 1% LP)</div>
      </div>
      <div className="app-data-token">
        <div className="app-data-token-item">
          <div className="app-data-token-item-title">Token Farming</div>
          <div>Token Farming</div>
          <div>Token Farming</div>
        </div>
        <div className="app-data-token-item">
          <div className="app-data-token-item-title"> Tokenomics </div>
          <div className="app-data-token-item-content"> Supply Cap </div>
          <div className="app-data-token-item-price"> 100,000,000,000,000 </div>
          <div className="app-data-token-item-content"> Ticker </div>
          <div className="app-data-token-item-price"> $RPG </div>
        </div>
        <div className="app-data-token-item">
          <div className="app-data-token-item-title">Market Cap</div>
          <div className="app-data-token-item-content">Market Cap</div>
          <div className="app-data-token-item-price">1.9M</div>
          <div className="app-data-token-item-content"> Price</div>
          <div className="app-data-token-item-price"> $0.00000001891</div>
        </div>
      </div>
    </div>
  );
};

export default AppData;
