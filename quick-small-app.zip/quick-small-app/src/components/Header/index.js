import "./index.css";



const AppHeader = () => {
const iconList = [
  {
    name: "A",
  },
  {
    name: "B",
  },
  {
    name: "C",
  },
  {
    name: "D",
  },
];
  return (
    <div className="app-header">
      <div className="app-header-left">
        <div className="app-header-logo"> Left </div>
      </div>
      <div className="app-header-right">
        <div className="app-header-menu">
          {iconList.map((item) => {
            return <div className="app-header-menu-item">{item.name}</div>;
          })}
        </div>
        <div className="app-header-connect">Connect</div>
      </div>
    </div>
  );
};

export default AppHeader;
